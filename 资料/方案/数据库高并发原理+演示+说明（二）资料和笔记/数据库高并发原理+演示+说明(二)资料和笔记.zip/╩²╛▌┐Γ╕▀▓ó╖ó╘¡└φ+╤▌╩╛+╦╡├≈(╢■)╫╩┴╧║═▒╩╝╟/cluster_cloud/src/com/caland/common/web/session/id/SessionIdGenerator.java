package com.caland.common.web.session.id;

/**
 * session id 生成接口
 */
public interface SessionIdGenerator {
	public String get();
}
